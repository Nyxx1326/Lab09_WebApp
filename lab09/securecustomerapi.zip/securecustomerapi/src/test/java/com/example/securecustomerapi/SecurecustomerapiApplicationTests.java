package com.example.securecustomerapi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SecurecustomerapiApplicationTests {

	@Test
	void contextLoads() {
	}

}
